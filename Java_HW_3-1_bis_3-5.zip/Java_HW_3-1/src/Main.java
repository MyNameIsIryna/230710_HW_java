import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1) Напишите программу, в которой объявите переменные
        // всех примитивных типов. Значение для каждой переменной
        // сгенерируйте с помощью класса Random. При необходимости
        // используйте приведение типов. Полученные значения выведите в консоль.
        //2) В этой же программе создайте переменную типа String.
        // Сгенерируйте значение для строки. При необходимости используйте
        // метод String.valueOf(). Ограничений на длину строки и содержимое нет.
        // Полученное значение выведите в консоль.

        Random rnd = new Random();
        int rndInt = rnd.nextInt();
        double rndDoub = rnd.nextDouble();
        float rndFloat = rnd.nextFloat();
        long rndLong = rnd.nextLong();
        boolean rndBool = rnd.nextBoolean();
        char rndChar = (char) rnd.nextInt('a', 'z' + 1);
        byte rndByte = (byte) rnd.nextInt(256);
        short rndShort = (short) rnd.nextInt(Short.MAX_VALUE);

        //add(int num1, int num2) => return num1 + num2

System.out.println(rndInt+"---"+rndDoub+"---"+rndFloat +"---"+rndLong+"---"+rndBool+"---"+rndChar+"---"+rndByte+"---"+rndShort);
        String rndStr = String.valueOf((char)rnd.nextInt('a','z'+1))+String.valueOf((char)rnd.nextInt('a','z'+1));
        System.out.println("STRING " + rndStr);

//3) Schreiben Sie ein Programm, das vom Benutzer seinen Namen, sein Alter (ganze Jahre) und sein Gewicht erhält.
// Wenn alle Daten eingegeben wurden, sollte das Programm die Meldung anzeigen: „Sehr geehrte Damen und Herren,
// [Name]! In deinem [Alter] Alter bist du uns so teuer wie ein [Gewicht] Kilogramm Gold.“ Die Meldungen [Name],
// [Alter] und [Gewicht] sollten die eingegebenen Werte akzeptieren.
        Scanner scn = new Scanner(System.in);
        System.out.println("Wie ist dein Name? ");
        String scnName = scn.next();

        System.out.println("Wie alt bist du? ");
        int scnAlter = scn.nextInt();
        System.out.println("Wie viel wiegst du? ");
        int scnGewicht = scn.nextInt();

        System.out.println("Sehr geehrte Frau, sehr geehrter Herr " +
                scnName + "!" + "\n In deinen " + scnAlter + " Jahren bist du uns so teuer wie ein " + scnGewicht + " Kilogramm Gold.");


        /*4b) Schreiben Sie ein Programm, das vom Benutzer zwei ganze Zahlen empfängt und dann die Summe (Addition), Differenz (Subtraktion),
         Produkt (Multiplikation) und Quotient (Division) der eingegebenen Zahlen berechnet. Geben Sie das Berechnungsergebnis an die
         Konsole aus.  */
        Scanner scnDig = new Scanner(System.in);
        System.out.println("Gib bitte eine Zahl ein ");
        int eingabeA1 = scnDig.nextInt();

        System.out.println("Gib bitte einen Operator ein ");
        String operator1 = "/";
        String operator2 = "*";
        String operator3 = "+";
        String operator4 = "-";

        String eingabeX1 = scnDig.next();

        System.out.println("Gib bitte noch eine Zahl ein ");
        int eingabeB1 = scnDig.nextInt();

        switch (eingabeX1) {
            case "+":
                System.out.println("Die Summe von " + (eingabeA1 + eingabeX1 + eingabeB1) + "=" + (eingabeA1 + eingabeB1));
                break;
            default:
                System.out.println("falsche Eingabe");
        }

        System.out.println("Zweite Runde: Gib bitte eine neue Zahl ein ");
        int eingabeA2 = scnDig.nextInt();

        System.out.println("Gib bitte einen neuen Operator ein ");
        String eingabeX2 = scnDig.next();

        System.out.println("Gib bitte noch eine neue Zahl ein ");
        int eingabeB2 = scnDig.nextInt();

        switch (eingabeX2) {
            case "-":
                System.out.println("Die Differenz von " + (eingabeA2 + eingabeX2 + eingabeB2) + "=" + (eingabeA2 - eingabeB2));
                break;
            default:
                System.out.println("falsche Eingabe");
        }

        System.out.println("Dritte Runde: Gib bitte eine neue Zahl ein ");
        int eingabeA3 = scnDig.nextInt();

        System.out.println("Gib bitte einen neuen Operator ein ");
        String eingabeX3 = scnDig.next();

        System.out.println("Gib bitte noch eine neue Zahl ein ");
        int eingabeB3 = scnDig.nextInt();

        switch (eingabeX3) {
            case "/":
                System.out.println("Die Division von " + (eingabeA3 + eingabeX3 + eingabeB3) + "=" + (eingabeA3 / eingabeB3));
                break;
            default:
                System.out.println("falsche Eingabe");
        }

        System.out.println("Vierte Runde: Gib bitte eine neue Zahl ein ");
        int eingabeA4 = scnDig.nextInt();

        System.out.println("Gib bitte einen neuen Operator ein ");
        String eingabeX4 = scnDig.next();

        System.out.println("Gib bitte noch eine neue Zahl ein ");
        int eingabeB4 = scnDig.nextInt();

        switch (eingabeX4) {
            case "*":
                System.out.println("Die Multiplikation von " + (eingabeA4 + eingabeX4 + eingabeB4) + "=" + (eingabeA4 * eingabeB4));
                break;
            default:
                System.out.println("falsche Eingabe");
        }

        /*5) Напишите программу, в которой с помощью Math.random() генерируются два числа типа double (a и b). Выведите числа в
        консоль. Используя методы класса Math вычислите значение : 1) разницы чисел, взятой по модулю – Math.abs(a - b), 2) минимальное из
        двух значений – Math.min(a, b), 3) максимальное из двух значений – Math.max(a, b), 4<) возведение первого числа в степень,
        где второе число, умноженное на 10 – это основание – Math.pow(a, b*10). Результаты всех вычислений выведите в консоль.*/
        double a = Math.random();
        double b = Math.random();
        System.out.println(a + " und " + b + "   ///  absolute Differenz: " + (Math.abs(a - b)) +
                "   ///  minimale Zahl: " + (Math.min(a, b)) + "   ///  maximale Zahl: " + (Math.max(a, b)) +
                "   ///  Potenziierung mit der Basis b*10: " + (Math.pow(a, b * 10)));

    }
}