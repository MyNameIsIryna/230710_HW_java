public class Main {
    public static void main(String[] args) {

        System.out.println("HW 1-2: Create a new project with JDK 8. It's strange but JDK 8 calls JDK 1.8");
    }
}