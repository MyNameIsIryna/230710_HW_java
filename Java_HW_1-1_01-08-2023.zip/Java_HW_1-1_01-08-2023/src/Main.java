public class Main {
    public static void main(String[] args) {
        System.out.println("HW 1: Create a project with JDK 11");
        System.out.println("Hello world!");
    }
}