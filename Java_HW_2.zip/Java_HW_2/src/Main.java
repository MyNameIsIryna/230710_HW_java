import org.w3c.dom.ls.LSOutput;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        char one = 'G';
        int two = 89;
        byte three = 4;
        short four = 8;
        float fife = 4.7333436F;
        double six = 4.355453532;
        long seven = 12121L;
        System.out.println(one + " --- " + two + " --- " + three + " --- " + fife + " --- " + six + " --- " + seven);
        System.out.println("____________________________");

        System.out.println();


    int a = 345;
    int threeDigitNumber = a / 100;
    int doubleDigit = a % 100 / 10;
    int digit = a % 100 % 10;
        System.out.println(threeDigitNumber);
        System.out.println(doubleDigit);
        System.out.println(digit);
        System.out.println("____________________________");}
}